package org.cap.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.login.pojo.Employee;
import org.cap.login.service.LoginService;
import org.cap.login.service.LoginServiceImpl;

public class SearchServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginService loginService=new LoginServiceImpl();
		
		List<Employee> emps=loginService.getAllEmployees();
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>"
				+ "<head>"
				
				+ "</head>"
				+ "<script type='text/javascript' src='script/myScript.js'> "
				+ "</script>"
				+ "<body><form name='empForm' method='get'>");
		
		out.println("<div style='padding:30px 30px 30px 30px;border:1px solid;'>Choose Employee Id:");
		out.println("<select name='empId'>");
		
		for(Employee emp:emps){
			out.println("<option value='"+emp.getEmpId()+"'>" + emp.getEmpId() +"</option>");
		}
				
				out.println("</select> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
						+ "<input type='button' onclick='searchEmployee()' name='search' value='Search'>");
		
		out.println("</div>"
				+ "<div id='result' style='border:1px solid; margin:5px 5px 5px 5px;width:500px; height:300px; padding:30px 30px 30px 30px;'>"
				+ ""
				+ "<div>"
				+ "</form></body></html>");
	}

}
